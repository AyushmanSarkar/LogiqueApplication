### LogiqueApplication
average app
